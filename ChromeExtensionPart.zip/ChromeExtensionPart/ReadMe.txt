Malicious Url Detector 1.0 
Instructions To Use Our ML Enabled Chrome Extension.

1. Open Google Chrome.
2. Open Extension Settings from the menu.
3. Select 'Load Unpacked' Option.
4. Choose the 'extension' folder from the Chrome Extension Folder.
   The extension would be unpacked in your Chrome browser.
5. Open cmd and run 'web.py' python script.
6. Once the script is running, restart your browser. The Malicious Url Detector will
   provide real time URL classification.

Thank You

